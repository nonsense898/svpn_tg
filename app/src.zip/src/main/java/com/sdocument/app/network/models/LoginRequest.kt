package com.sdocument.app.network.models

import com.google.gson.annotations.SerializedName

data class LoginRequest(
    @SerializedName("access_key") val accessKey: String,
    @SerializedName("device_id") val deviceId: String
)
