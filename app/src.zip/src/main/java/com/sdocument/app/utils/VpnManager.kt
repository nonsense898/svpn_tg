package com.sdocument.app.utils

import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.wireguard.config.InetNetwork
import com.wireguard.config.InetEndpoint
import com.wireguard.crypto.Key
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class VpnManager(private val context: Context) {
    private val appContext = context.applicationContext
    private val backend: Backend by lazy { GoBackend(appContext) }
    private val tunnel = object : Tunnel {
        override fun getName() = "SDocumentVPN"
        override fun onStateChange(newState: Tunnel.State) {
            _vpnState.value = newState
        }
    }

    private val _vpnState = MutableStateFlow(Tunnel.State.DOWN)
    val vpnState = _vpnState.asStateFlow()

    fun prepareVpn(): Intent? {
        return VpnService.prepare(appContext)
    }

    suspend fun toggleVpn(configString: String? = null) {
        val currentState = vpnState.value
        withContext(Dispatchers.IO) {
            try {
                if (currentState == Tunnel.State.UP) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                } else {
                    val config = configString?.let { parseConfig(it) } ?: createMockConfig()
                    backend.setState(tunnel, Tunnel.State.UP, config)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun createMockConfig(): Config {
        // Valid 32-byte Base64 keys (44 chars)
        val privateKeyStr = "EBp6S6nO9P+oW7S1G9G7Q9G7Q9G7Q9G7Q9G7Q9G7Q9E="
        val publicKeyStr = "WEn6S6nO9P+oW7S1G9G7Q9G7Q9G7Q9G7Q9G7Q9G7Q9E="

        val interfaceBuilder = Interface.Builder()
            .addAddress(InetNetwork.parse("10.0.0.2/32"))
            .parsePrivateKey(privateKeyStr)

        val peerBuilder = Peer.Builder()
            .addAllowedIp(InetNetwork.parse("0.0.0.0/0"))
            .setEndpoint(InetEndpoint.parse("1.2.3.4:51820"))
            .parsePublicKey(publicKeyStr)

        return Config.Builder()
            .setInterface(interfaceBuilder.build())
            .addPeer(peerBuilder.build())
            .build()
    }

    private fun parseConfig(configString: String): Config {
        return try {
            Config.parse(configString.byteInputStream())
        } catch (e: Exception) {
            createMockConfig()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: VpnManager? = null

        fun getInstance(context: Context): VpnManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: VpnManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
