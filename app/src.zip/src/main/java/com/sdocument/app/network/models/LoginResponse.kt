package com.sdocument.app.network.models

import com.google.gson.annotations.SerializedName

data class LoginResponse(
    @SerializedName("status") val status: String,
    @SerializedName("url") val url: String? = null,
    @SerializedName("error") val error: String? = null
)
