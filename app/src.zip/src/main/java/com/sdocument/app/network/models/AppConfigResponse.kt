package com.sdocument.app.network.models

import com.google.gson.annotations.SerializedName

data class AppConfigResponse(
    @SerializedName("url") val url: String?,
    @SerializedName("credentials") val credentialsJson: String?
)
