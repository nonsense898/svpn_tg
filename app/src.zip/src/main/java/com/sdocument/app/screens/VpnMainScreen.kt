package com.sdocument.app.screens

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sdocument.app.utils.UserPrefs
import com.sdocument.app.utils.VpnManager
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun VpnMainScreen(
    onSelectServer: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val context = LocalContext.current
    val vpnManager = remember { VpnManager.getInstance(context) }
    val vpnState by vpnManager.vpnState.collectAsState()
    
    val isConnected = vpnState == Tunnel.State.UP
    var isConnecting by remember { mutableStateOf(false) }
    
    var selectedServer by remember { mutableStateOf(UserPrefs.getSelectedServer(context)) }
    var connectionTime by remember { mutableStateOf(0) }
    val coroutineScope = rememberCoroutineScope()

    val vpnLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            coroutineScope.launch {
                isConnecting = true
                vpnManager.toggleVpn()
                delay(1000)
                isConnecting = false
            }
        }
    }

    val bgColor by animateColorAsState(
        targetValue = if (isConnected) Color(0xFF1B5E20) else MaterialTheme.colorScheme.background,
        label = "bgColor"
    )

    LaunchedEffect(isConnected) {
        if (isConnected) {
            while (true) {
                delay(1000)
                connectionTime++
            }
        } else {
            connectionTime = 0
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
            .statusBarsPadding()
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onOpenProfile) {
                Icon(Icons.Default.Person, contentDescription = "Profile", tint = Color.White)
            }
            Text(
                text = "VPN SERVICE",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
            }
        }

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Connection Status
            Text(
                text = if (isConnecting) "ПОДКЛЮЧЕНИЕ..." else if (isConnected) "ПОДКЛЮЧЕНО" else "ОТКЛЮЧЕНО",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White.copy(alpha = 0.8f),
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (isConnected) {
                Text(
                    text = formatTime(connectionTime),
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Spacer(modifier = Modifier.height(20.dp))
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Power Button
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .clip(CircleShape)
                    .background(if (isConnected) Color.White.copy(alpha = 0.1f) else Color.White.copy(alpha = 0.05f))
                    .clickable(enabled = !isConnecting) {
                        coroutineScope.launch {
                            if (isConnected) {
                                isConnecting = true
                                vpnManager.toggleVpn()
                                delay(500)
                                isConnecting = false
                            } else {
                                val intent = vpnManager.prepareVpn()
                                if (intent != null) {
                                    vpnLauncher.launch(intent)
                                } else {
                                    isConnecting = true
                                    vpnManager.toggleVpn()
                                    delay(1000)
                                    isConnecting = false
                                }
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .clip(CircleShape)
                        .background(if (isConnected) Color.White else Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isConnecting) {
                        CircularProgressIndicator(color = Color.Black)
                    } else {
                        Text(
                            text = if (isConnected) "OFF" else "ON",
                            style = MaterialTheme.typography.headlineLarge,
                            color = if (isConnected) Color.Black else Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(64.dp))

            // Server Selection Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp)
                    .clickable { onSelectServer() },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f))
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Текущий сервер", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                            Text(selectedServer, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("ИЗМЕНИТЬ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

private fun formatTime(seconds: Int): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return String.format("%02d:%02d:%02d", h, m, s)
}
