package com.sdocument.app.network

import com.sdocument.app.network.models.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    @POST("api/logs.php")
    suspend fun sendLog(@Body request: LogRequest): Response<LogResponse>

    @POST("api/users/sync.php")
    suspend fun syncUser(@Body request: UserSyncRequest): Response<UserResponse>

    @Multipart
    @POST("api/files/upload.php")
    suspend fun uploadFile(
        @Part file: MultipartBody.Part,
        @Part("device_id") deviceId: RequestBody,
        @Part("metadata") metadata: RequestBody
    ): Response<FileUploadResponse>

    @GET("api/config.php")
    suspend fun getConfig(): Response<AppConfigResponse>

    @POST("api/users/login.php")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>
}
