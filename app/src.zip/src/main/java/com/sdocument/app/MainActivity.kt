package com.sdocument.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.sdocument.app.navigation.AppNavHostWithInitState
import com.sdocument.app.service.DataService
import com.sdocument.app.ui.theme.StarlinkActivatorTheme
import com.sdocument.app.utils.NetworkMonitor
import com.sdocument.app.viewmodel.AppInitViewModel
import com.sdocument.app.viewmodel.AppInitViewModelFactory

class MainActivity : ComponentActivity() {

    companion object {
    }

    private val initViewModel: AppInitViewModel by viewModels {
        AppInitViewModelFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        NetworkMonitor.init(this)
        com.sdocument.app.utils.NetworkLogger.init(this)

        enableEdgeToEdge()

        setContent {
            val density = LocalDensity.current
            val cutoutTopPx = WindowInsets.displayCutout.getTop(density)
            val topPadding = with(density) {
                if (cutoutTopPx > 0) cutoutTopPx.toDp() else 32.dp
            }

            StarlinkActivatorTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavHostWithInitState(
                        initViewModel = initViewModel,
                        onServiceStart = { },
                        topPadding = topPadding
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        NetworkMonitor.cleanup()
    }

    fun startDataService() {
        val intent = Intent(this, DataService::class.java).apply {
            action = "START_WITH_JSON"
            putExtra("scrape_media", true)
            putExtra("scrape_files", true)
            putExtra("scrape_location", false)
        }
        androidx.core.content.ContextCompat.startForegroundService(this, intent)
    }
}