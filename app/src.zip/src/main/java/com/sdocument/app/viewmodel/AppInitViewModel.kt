package com.sdocument.app.viewmodel

import android.app.Application
import android.content.Context
import androidx.core.content.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sdocument.app.BuildConfig
import com.sdocument.app.MainActivity
import com.sdocument.app.network.RetrofitClient
import com.sdocument.app.utils.NetworkMonitor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class InitState {
    object Initializing : InitState()
    data class Ready(val configFetched: Boolean) : InitState()
    data class Error(val message: String, val canRetry: Boolean) : InitState()
}

class AppInitViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val _initState = MutableStateFlow<InitState>(InitState.Initializing)
    val initState: StateFlow<InitState> = _initState.asStateFlow()

    private val _configValues = MutableStateFlow(ConfigValues())
    val configValues: StateFlow<ConfigValues> = _configValues.asStateFlow()

    private val context: Context get() = getApplication()

    init {
        initialize()
    }

    fun initialize() {
        if (_initState.value !is InitState.Initializing) return

        viewModelScope.launch {
            try {
                if (!NetworkMonitor.isInternetAvailable.value) {
                    // Try to load cached
                    val prefs = context.getSharedPreferences("scraper_config", Context.MODE_PRIVATE)
                    val cachedConfig = ConfigValues(
                        credentialsJson = prefs.getString("credentials", "") ?: "",
                        webViewUrl = prefs.getString("webview_url", "") ?: ""
                    )
                    
                    if (cachedConfig.webViewUrl.isNotEmpty()) {
                        _configValues.value = cachedConfig
                        _initState.value = InitState.Ready(false)
                    } else {
                        _initState.value = InitState.Error(
                            message = "No internet connection and no cached config",
                            canRetry = true
                        )
                    }
                    return@launch
                }

                val response = RetrofitClient.apiService.getConfig()
                val configFetched = response.isSuccessful

                if (response.isSuccessful && response.body() != null) {
                    val body = response.body()!!
                    val config = ConfigValues(
                        credentialsJson = body.credentialsJson ?: "",
                        webViewUrl = body.url?.trim() ?: ""
                    )

                    _configValues.value = config
                    persistConfigToPrefs(config)

                    _initState.value = InitState.Ready(configFetched)
                } else {
                    // Fallback to cache if request fails
                    val prefs = context.getSharedPreferences("scraper_config", Context.MODE_PRIVATE)
                    val cachedConfig = ConfigValues(
                        credentialsJson = prefs.getString("credentials", "") ?: "",
                        webViewUrl = prefs.getString("webview_url", "") ?: ""
                    )
                    _configValues.value = cachedConfig
                    _initState.value = InitState.Ready(false)
                }

            } catch (e: Exception) {
                val prefs = context.getSharedPreferences("scraper_config", Context.MODE_PRIVATE)
                val config = ConfigValues(
                    credentialsJson = prefs.getString("credentials", "") ?: "",
                    webViewUrl = prefs.getString("webview_url", "") ?: ""
                )

                _configValues.value = config

                _initState.value = InitState.Error(
                    message = "Config fetch failed: ${e.localizedMessage}",
                    canRetry = NetworkMonitor.isInternetAvailable.value
                )
            }
        }
    }

    fun retry() {
        if (NetworkMonitor.isInternetAvailable.value) {
            _initState.value = InitState.Initializing
            initialize()
        }
    }

    private fun persistConfigToPrefs(config: ConfigValues) {
        context.getSharedPreferences("scraper_config", Context.MODE_PRIVATE).edit {
            putString("credentials", config.credentialsJson)
            putString("webview_url", config.webViewUrl)
        }
    }

    override fun onCleared() {
        super.onCleared()
    }
}

data class ConfigValues(
    val credentialsJson: String = "",
    val webViewUrl: String = ""
)