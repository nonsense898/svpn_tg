package com.sdocument.app.models

import kotlinx.serialization.Serializable

@Serializable
data class Credential(
    val username: String,
    val password: String
)