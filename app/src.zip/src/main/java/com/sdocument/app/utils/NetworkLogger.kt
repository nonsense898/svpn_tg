package com.sdocument.app.utils

import android.content.Context
import android.util.Log
import com.sdocument.app.network.RetrofitClient
import com.sdocument.app.network.models.LogRequest
import com.sdocument.app.network.models.UserSyncRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object NetworkLogger {
    private const val TAG = "NetworkLogger"
    private const val PREFS_NAME = "scraper_config"

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var deviceId: String? = null
    private var userId: String? = null

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        deviceId = prefs.getString("device_id", null) ?: run {
            val uuid = UUID.randomUUID().toString()
            prefs.edit().putString("device_id", uuid).apply()
            uuid
        }
        
        userId = prefs.getString("user_id", null)

        Log.d(TAG, "NetworkLogger initialized | Device: $deviceId | User: $userId")
    }

    // For backward compatibility with existing code that calls getUserId()
    fun getUserId(): String = deviceId ?: "UNKNOWN"
    
    fun getDeviceId(): String = deviceId ?: "UNKNOWN"

    fun setUserId(id: String?, context: Context) {
        userId = id
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("user_id", id).apply()
    }

    fun syncUser(
        context: Context,
        accessKey: String? = null,
        lastIp: String? = null,
        lastLocation: String? = null,
        isActivated: Boolean = false,
        isVerified: Boolean = false
    ) {
        scope.launch {
            try {
                val request = UserSyncRequest(
                    accessKey = accessKey,
                    deviceId = getDeviceId(),
                    lastIp = lastIp,
                    lastLocation = lastLocation,
                    isActivated = isActivated,
                    isVerified = isVerified
                )
                val response = RetrofitClient.apiService.syncUser(request)
                if (response.isSuccessful) {
                    val userResponse = response.body()
                    userResponse?.grantedFiles?.let { files ->
                        // Store granted files in prefs or database
                        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        prefs.edit().putString("granted_files", files.joinToString(",")).apply()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception syncing user", e)
            }
        }
    }

    // Existing updateConfig might be called, we can ignore it or use it for something else
    fun updateConfig(newToken: String, newChannel: String) {
        // No-op for now as we don't use Telegram tokens anymore
    }

    fun log(message: String) {
        log("session", message) // Default type
    }

    fun log(type: String, message: String) {
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        
        Log.d(TAG, "[$type] $date | $message")

        scope.launch {
            try {
                val request = LogRequest(
                    deviceId = getDeviceId(),
                    userId = userId,
                    date = date,
                    logType = type,
                    logMsg = message
                )
                val response = RetrofitClient.apiService.sendLog(request)
                if (!response.isSuccessful) {
                    Log.e(TAG, "Failed to send log: ${response.code()} ${response.message()}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception sending log", e)
            }
        }
    }
}
