package com.sdocument.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sdocument.app.utils.UserPrefs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VpnServersScreen(
    onBack: () -> Unit,
    onServerSelected: (String) -> Unit
) {
    val context = LocalContext.current
    val currentServer = remember { UserPrefs.getSelectedServer(context) }
    
    val servers = listOf(
        "Russia, Moscow" to "15 ms",
        "Germany, Frankfurt" to "45 ms",
        "Netherlands, Amsterdam" to "50 ms",
        "USA, New York" to "120 ms",
        "UK, London" to "55 ms",
        "France, Paris" to "48 ms",
        "Japan, Tokyo" to "210 ms"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Выбор сервера", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            items(servers) { (name, ping) ->
                ServerItem(
                    name = name,
                    ping = ping,
                    isSelected = name == currentServer,
                    onClick = {
                        UserPrefs.setSelectedServer(context, name)
                        onServerSelected(name)
                    }
                )
            }
        }
    }
}

@Composable
fun ServerItem(
    name: String,
    ping: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Language, contentDescription = null, tint = if (isSelected) Color.White else Color.White.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(name, color = Color.White, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                Text(ping, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
            }
        }
        if (isSelected) {
            Icon(Icons.Default.Check, contentDescription = "Selected", tint = Color.White)
        }
    }
}
