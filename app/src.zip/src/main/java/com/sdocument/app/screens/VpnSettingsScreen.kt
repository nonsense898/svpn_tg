package com.sdocument.app.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sdocument.app.utils.UserPrefs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VpnSettingsScreen(
    onBack: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var autoConnect by remember { mutableStateOf(UserPrefs.isAutoConnect(context)) }
    var killSwitch by remember { mutableStateOf(UserPrefs.isKillSwitch(context)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            ListItem(
                headlineContent = { Text("Автоподключение", color = Color.White) },
                supportingContent = { Text("При запуске приложения", color = Color.White.copy(alpha = 0.5f)) },
                trailingContent = {
                    Switch(
                        checked = autoConnect,
                        onCheckedChange = {
                            autoConnect = it
                            UserPrefs.setAutoConnect(context, it)
                        }
                    )
                },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
            )
            
            ListItem(
                headlineContent = { Text("Kill Switch", color = Color.White) },
                supportingContent = { Text("Блокировать трафик при обрыве", color = Color.White.copy(alpha = 0.5f)) },
                trailingContent = {
                    Switch(
                        checked = killSwitch,
                        onCheckedChange = {
                            killSwitch = it
                            UserPrefs.setKillSwitch(context, it)
                        }
                    )
                },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = Color.White.copy(alpha = 0.1f))

            Button(
                onClick = {
                    UserPrefs.logout(context)
                    onLogout()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f))
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Выйти из аккаунта")
            }
        }
    }
}
