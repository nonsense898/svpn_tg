package com.sdocument.app.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sdocument.app.network.RetrofitClient
import com.sdocument.app.network.models.LoginRequest
import com.sdocument.app.utils.NetworkLogger
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    initialWebViewUrl: String,
    onAuthSuccess: (String, String) -> Unit,
    onAuthError: () -> Unit = {},
    topPadding: Dp = 32.dp,
    modifier: Modifier = Modifier
) {
    // We use TextFieldValue to better control cursor position
    var accessKeyFieldValue by remember { mutableStateOf(TextFieldValue("")) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(top = topPadding)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Активация доступа", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Введите ваш ключ доступа", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.6f))
        Text("Формат: XXXX-XXXX-XXXX", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.4f))
        
        Spacer(Modifier.height(32.dp))

        OutlinedTextField(
            value = accessKeyFieldValue,
            onValueChange = { newValue ->
                // Filter only alphanumeric and limit to 12 characters
                val cleaned = newValue.text.uppercase().filter { it.isLetterOrDigit() }.take(12)
                
                // Smart cursor handling
                val newSelection = if (cleaned.length > accessKeyFieldValue.text.length && newValue.selection.start < cleaned.length) {
                    // If appending at the end, keep cursor at the end
                    if (newValue.selection.start == newValue.text.length) {
                         TextRange(cleaned.length)
                    } else {
                        // If inserting in the middle, try to preserve cursor relative to content
                         newValue.selection
                    }
                } else {
                    newValue.selection
                }

                accessKeyFieldValue = TextFieldValue(
                    text = cleaned,
                    selection = if (newSelection.start > cleaned.length) TextRange(cleaned.length) else newSelection
                )
            },
            label = { Text("Ключ доступа") },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading,
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            placeholder = { Text("0000-0000-0000") },
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Characters,
                autoCorrect = false,
                keyboardType = KeyboardType.Ascii
            ),
            visualTransformation = KeyVisualTransformation()
        )

        errorMessage?.let { msg ->
            Spacer(Modifier.height(8.dp))
            Text(
                msg,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Spacer(Modifier.height(32.dp))

        Button(
            onClick = {
                val rawKey = accessKeyFieldValue.text
                if (rawKey.length < 12) {
                    errorMessage = "Ключ должен содержать 12 символов"
                    return@Button
                }

                isLoading = true
                errorMessage = null

                coroutineScope.launch {
                    try {
                        // Format it for the backend which expects dashes
                        val formattedKey = buildString {
                            for (i in rawKey.indices) {
                                append(rawKey[i])
                                if ((i == 3 || i == 7) && i != rawKey.lastIndex) {
                                    append("-")
                                }
                            }
                        }

                        val request = LoginRequest(
                            accessKey = formattedKey,
                            deviceId = NetworkLogger.getDeviceId()
                        )
                        val response = RetrofitClient.apiService.login(request)
                        
                        isLoading = false
                        if (response.isSuccessful && response.body()?.status == "success") {
                            val successUrl = response.body()?.url ?: initialWebViewUrl
                            onAuthSuccess(successUrl, formattedKey)
                        } else {
                            errorMessage = response.body()?.error ?: "Неверный или неактивный ключ"
                            onAuthError()
                        }
                    } catch (e: Exception) {
                        isLoading = false
                        errorMessage = "Ошибка подключения к серверу"
                        onAuthError()
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            enabled = !isLoading,
            shape = RoundedCornerShape(12.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            } else {
                Text("АКТИВИРОВАТЬ", fontWeight = FontWeight.Bold)
            }
        }
    }
}

class KeyVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text
        val out = buildString {
            for (i in raw.indices) {
                append(raw[i])
                if ((i == 3 || i == 7) && i != raw.lastIndex) {
                    append("-")
                }
            }
        }

        val offsetMapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                if (offset <= 4) return offset
                if (offset <= 8) return offset + 1
                return offset + 2
            }

            override fun transformedToOriginal(offset: Int): Int {
                if (offset <= 4) return offset
                if (offset <= 9) return offset - 1
                return offset - 2
            }
        }

        return TransformedText(AnnotatedString(out), offsetMapping)
    }
}
